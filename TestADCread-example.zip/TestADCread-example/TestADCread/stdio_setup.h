#ifndef STDIO_SETUP_H_
#define STDIO_SETUP_H_

void UartInit(void);

#endif /* STDIO_SETUP_H_ */
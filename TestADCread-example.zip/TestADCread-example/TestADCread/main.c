/*
 * TestADCread.c
 *  Use this to test the ADClib library.
 * uses stdio_setup to print output to USB serial port (Uno)
 * Created: 2/28/2021 10:19:52 AM
 * Author : clamm
 */ 
#define F_CPU 16000000UL
#define BAUD 9600
#define BAUD_TOL 2
#include "ADClib.h"
#include "stdio_setup.h"
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdint.h>



uint8_t v;
uint16_t q ;

int main(void)
{  
	UartInit();
	ADC_init();
    
   

    while (1) 
    {
    v = analogRead8bit();
	q = analogRead10bit();
    _delay_ms(500);
	printf("From main: 8 bit input is: %0d \n\r",v);
	_delay_ms(500);
	printf("From main: 10 bit input is: %u \n\r",q);
    printf("--------------------------\n\r");
    }
}
 